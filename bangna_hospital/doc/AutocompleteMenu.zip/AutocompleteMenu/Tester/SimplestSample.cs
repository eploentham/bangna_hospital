﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Tester
{
    public partial class SimplestSample : Form
    {
        public SimplestSample()
        {
            InitializeComponent();
        }
    }
}
